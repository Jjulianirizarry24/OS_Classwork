#include "functions.h"

int main() { mainProcess(); }
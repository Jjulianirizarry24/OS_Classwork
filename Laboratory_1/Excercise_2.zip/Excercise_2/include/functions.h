#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void fill_date(long second, int* day, int* month, int* year);
void is_leap_year(int* year, int months[]);

#endif
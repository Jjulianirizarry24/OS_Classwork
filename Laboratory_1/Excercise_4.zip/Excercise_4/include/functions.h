#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void upper_rand(char* base, char* mod);
void print_arrays(char* base, char* mod);

#endif
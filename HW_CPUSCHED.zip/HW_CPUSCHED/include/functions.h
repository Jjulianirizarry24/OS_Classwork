#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void mainProcess();
void changeAffinity();
void changeNice();
void *primeChecker(void *ptr);

#endif
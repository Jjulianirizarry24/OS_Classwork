#ifndef EXCERCISE1_H
#define EXCERCISE1_H

int cosine_series(int init_number, int end_number);


#endif
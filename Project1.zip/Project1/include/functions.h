#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void mainProcess();
void *posixTimer();
void *sleepFunction();

#endif
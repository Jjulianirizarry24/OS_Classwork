#include "functions.h"
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/**
 * @brief Main function
 * @return Exit status
 */
int main() { mainProcess(); }

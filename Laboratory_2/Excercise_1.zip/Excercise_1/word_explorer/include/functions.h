#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int ContainsWord(const char *filepath, const char *word);
void ExploreDirectory(const char *dirpath, const char *word);

#endif